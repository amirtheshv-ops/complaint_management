-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: geotag
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0aciy15r19l0sp7ixb567gfiyoeqad9v','.eJxVjMsOwiAQRf-FtSEMlEdduvcbyDADUjUlKe3K-O_apAvd3nPOfYmI21rj1vMSJxZnAeL0uyWkR553wHecb01Sm9dlSnJX5EG7vDbOz8vh_h1U7PVbOwdsCIgNg_ap6JQogKWgVRnQ-FAga6P8iEg2kCowQmBnbB5oVFmL9wfl3DfD:1wiutR:ji8sG-z9t2NHCpZu6fgDFRU71GRPCVUliTB-AeOwTBE','2026-07-26 14:10:53.534308'),('amjv97r5fvsk0lgw1qcl2zb3c2siup88','.eJxVjDsOgzAQRO_iOrJsbPxJmZ4zWLvsOpBEtoShinL3gESRVCPNezNvkWBbp7Q1XtJM4iqMuPx2COOTywHoAeVe5VjLuswoD0WetMmhEr9up_t3MEGb9jU6gqy9Dtwjd5r6rIzSrMj5LgeIETTaYNE7ytZZG_MehJQdoxktis8X8284mg:1wiv6L:nDqd6wjdOadoDjS0-T2v2lCBipYAm11i1ODMIW4RMk0','2026-07-26 14:24:13.869615'),('p66ob406hyb8pjzfd2yn6vojaos8a3nf','.eJxVjMsOgjAQRf-la9N0pgWKS_d8A5lHtagpCYWV8d-VhIVu7znnvsxI25rHraZlnNScDZrT78Ykj1R2oHcqt9nKXNZlYrsr9qDVDrOm5-Vw_w4y1fytyYsLnSJGkTa4pveRQRIHhxwaFu1i68BrD-iRE_IVwBEpa-AICOb9AdVBN58:1wiusx:T8C89IG7NyAc9Too3wj9Lrf4oQ7co9O4SkYaqDiAzHs','2026-07-26 14:10:23.697001');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-12 20:32:01
